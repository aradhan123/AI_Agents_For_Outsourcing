
  # Meeting Creation Screen

  This is a code bundle for Meeting Creation Screen. The original project is available at https://www.figma.com/design/9mG3NBVV43tlQI9zsHt3QQ/Meeting-Creation-Screen.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  