import { MeetingCreation } from './components/MeetingCreation';

export default function App() {
  return (
    <div className="size-full">
      <MeetingCreation />
    </div>
  );
}
