import { useState } from 'react';
import { Calendar, Clock, Users, MapPin, Video, Sparkles, Plus, X, ChevronDown, Upload, File } from 'lucide-react';
import { format } from 'date-fns';
import { MeetingDetailsModal } from './MeetingDetailsModal';

interface Participant {
  id: string;
  email: string;
}

interface UploadedFile {
  id: string;
  name: string;
  size: number;
}

export function MeetingCreation() {
  const [title, setTitle] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]); // Initialize with today's date
  const [time, setTime] = useState('');
  const [duration, setDuration] = useState('30');
  const [meetingType, setMeetingType] = useState<'virtual' | 'in-person'>('virtual');
  const [location, setLocation] = useState('');
  const [description, setDescription] = useState('');
  const [participants, setParticipants] = useState<Participant[]>([]);
  const [newParticipantEmail, setNewParticipantEmail] = useState('');
  const [showAISuggestions, setShowAISuggestions] = useState(false);
  const [showCalendarPicker, setShowCalendarPicker] = useState(false);
  const [showMeetingDetails, setShowMeetingDetails] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);

  // Generate time slots from 9 AM to 5 PM in 30-minute intervals
  const timeSlots = [];
  for (let hour = 9; hour <= 17; hour++) {
    for (let minute = 0; minute < 60; minute += 30) {
      if (hour === 17 && minute > 0) break; // Stop at 5:00 PM
      const time24 = `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;
      const isPM = hour >= 12;
      const hour12 = hour > 12 ? hour - 12 : hour === 0 ? 12 : hour;
      const displayTime = `${hour12}:${minute.toString().padStart(2, '0')} ${isPM ? 'PM' : 'AM'}`;
      timeSlots.push({ value: time24, display: displayTime });
    }
  }

  const addParticipant = () => {
    if (newParticipantEmail && newParticipantEmail.includes('@')) {
      setParticipants([...participants, { id: Date.now().toString(), email: newParticipantEmail }]);
      setNewParticipantEmail('');
    }
  };

  const removeParticipant = (id: string) => {
    setParticipants(participants.filter(p => p.id !== id));
  };

  const handleAIOptimize = () => {
    setShowAISuggestions(!showAISuggestions);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Meeting created:', { title, date, time, duration, meetingType, location, description, participants });
    // Show meeting details modal
    setShowMeetingDetails(true);
  };

  const formatSelectedDate = (dateString: string) => {
    if (!dateString) return 'Select a date';
    const dateObj = new Date(dateString + 'T00:00:00');
    return format(dateObj, 'EEEE, MMMM d, yyyy');
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      const newFiles: UploadedFile[] = Array.from(files).map(file => ({
        id: Date.now().toString() + Math.random(),
        name: file.name,
        size: file.size
      }));
      setUploadedFiles([...uploadedFiles, ...newFiles]);
    }
  };

  const removeFile = (id: string) => {
    setUploadedFiles(uploadedFiles.filter(f => f.id !== id));
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 bg-gradient-to-br from-violet-500 to-purple-600 rounded-lg flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-slate-900">Create New Meeting</h1>
          </div>
          <p className="text-slate-600 ml-13">AI-powered scheduling to find the perfect time for everyone</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Main Card */}
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-8">
            {/* Meeting Title */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Meeting Title *
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g., Q1 Planning Review"
                className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-violet-500 focus:border-transparent"
                required
              />
            </div>

            {/* Date Section */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-slate-700 mb-2">
                <Calendar className="w-4 h-4 inline mr-1" />
                Date *
              </label>
              <div className="p-4 border border-slate-300 rounded-lg bg-slate-50">
                <div className="text-slate-900 font-medium mb-2">
                  {formatSelectedDate(date)}
                </div>
                <button
                  type="button"
                  onClick={() => setShowCalendarPicker(!showCalendarPicker)}
                  className="text-sm text-violet-600 hover:text-violet-700 font-medium flex items-center gap-1"
                >
                  Change Date
                  <ChevronDown className={`w-4 h-4 transition-transform ${showCalendarPicker ? 'rotate-180' : ''}`} />
                </button>
                {showCalendarPicker && (
                  <div className="mt-3 pt-3 border-t border-slate-200">
                    <input
                      type="date"
                      value={date}
                      onChange={(e) => {
                        setDate(e.target.value);
                        setShowCalendarPicker(false);
                      }}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-violet-500 focus:border-transparent"
                      required
                    />
                  </div>
                )}
              </div>
            </div>

            {/* Time Selection Grid */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-slate-700 mb-2">
                <Clock className="w-4 h-4 inline mr-1" />
                Time *
              </label>
              <div className="grid grid-cols-4 gap-2">
                {timeSlots.map((slot) => (
                  <button
                    key={slot.value}
                    type="button"
                    onClick={() => setTime(slot.value)}
                    className={`px-3 py-2 rounded-lg border-2 text-sm transition-all ${
                      time === slot.value
                        ? 'border-violet-500 bg-violet-500 text-white'
                        : 'border-slate-300 bg-white text-slate-700 hover:border-violet-300'
                    }`}
                  >
                    {slot.display}
                  </button>
                ))}
              </div>
            </div>

            {/* Duration */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Duration
              </label>
              <select
                value={duration}
                onChange={(e) => setDuration(e.target.value)}
                className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-violet-500 focus:border-transparent"
              >
                <option value="15">15 min</option>
                <option value="30">30 min</option>
                <option value="45">45 min</option>
                <option value="60">1 hour</option>
                <option value="90">1.5 hours</option>
                <option value="120">2 hours</option>
              </select>
            </div>

            {/* AI Time Suggestions */}
            <div className="mb-6">
              <button
                type="button"
                onClick={handleAIOptimize}
                className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-violet-500 to-purple-600 text-white rounded-lg hover:from-violet-600 hover:to-purple-700 transition-all"
              >
                <Sparkles className="w-4 h-4" />
                AI Optimize Time
              </button>
              
              {showAISuggestions && (
                <div className="mt-4 p-4 bg-violet-50 border border-violet-200 rounded-lg">
                  <p className="text-sm font-medium text-slate-700 mb-3">Suggested optimal times:</p>
                  <div className="grid grid-cols-3 gap-2">
                    {suggestedTimes.map((suggestion, index) => (
                      <button
                        key={index}
                        type="button"
                        onClick={() => {
                          const timeParts = suggestion.time.split(' ');
                          const isPM = timeParts[1] === 'PM';
                          let hours = parseInt(timeParts[0].split(':')[0]);
                          if (isPM && hours !== 12) hours += 12;
                          if (!isPM && hours === 12) hours = 0;
                          setTime(`${hours.toString().padStart(2, '0')}:${timeParts[0].split(':')[1]}`);
                        }}
                        className="px-3 py-2 bg-white border border-violet-300 rounded-lg hover:bg-violet-100 transition-colors text-sm"
                      >
                        <div className="font-medium text-slate-900">{suggestion.time}</div>
                        <div className="text-xs text-slate-600">{suggestion.availability} availability</div>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Meeting Type */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-slate-700 mb-3">
                Meeting Type
              </label>
              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => setMeetingType('virtual')}
                  className={`flex-1 px-4 py-3 rounded-lg border-2 transition-all ${
                    meetingType === 'virtual'
                      ? 'border-violet-500 bg-violet-50'
                      : 'border-slate-300 bg-white hover:border-slate-400'
                  }`}
                >
                  <Video className="w-5 h-5 mx-auto mb-1" />
                  <div className="text-sm font-medium">Virtual</div>
                </button>
                <button
                  type="button"
                  onClick={() => setMeetingType('in-person')}
                  className={`flex-1 px-4 py-3 rounded-lg border-2 transition-all ${
                    meetingType === 'in-person'
                      ? 'border-violet-500 bg-violet-50'
                      : 'border-slate-300 bg-white hover:border-slate-400'
                  }`}
                >
                  <MapPin className="w-5 h-5 mx-auto mb-1" />
                  <div className="text-sm font-medium">In-Person</div>
                </button>
              </div>
            </div>

            {/* Location / Link */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-slate-700 mb-2">
                {meetingType === 'virtual' ? (
                  <>
                    <Video className="w-4 h-4 inline mr-1" />
                    Meeting Link
                  </>
                ) : (
                  <>
                    <MapPin className="w-4 h-4 inline mr-1" />
                    Location
                  </>
                )}
              </label>
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder={meetingType === 'virtual' ? 'https://meet.example.com/abc-123' : 'Conference Room A, Building 2'}
                className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-violet-500 focus:border-transparent"
              />
            </div>

            {/* Participants */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-slate-700 mb-2">
                <Users className="w-4 h-4 inline mr-1" />
                Participants
              </label>
              <div className="flex gap-2 mb-3">
                <input
                  type="email"
                  value={newParticipantEmail}
                  onChange={(e) => setNewParticipantEmail(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addParticipant())}
                  placeholder="Enter email address"
                  className="flex-1 px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-violet-500 focus:border-transparent"
                />
                <button
                  type="button"
                  onClick={addParticipant}
                  className="px-4 py-3 bg-violet-500 text-white rounded-lg hover:bg-violet-600 transition-colors"
                >
                  <Plus className="w-5 h-5" />
                </button>
              </div>
              
              {participants.length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {participants.map((participant) => (
                    <div
                      key={participant.id}
                      className="flex items-center gap-2 px-3 py-2 bg-slate-100 rounded-lg"
                    >
                      <span className="text-sm text-slate-700">{participant.email}</span>
                      <button
                        type="button"
                        onClick={() => removeParticipant(participant.id)}
                        className="text-slate-500 hover:text-slate-700"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Description */}
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Description / Agenda
              </label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Add meeting agenda, notes, or any additional details..."
                rows={5}
                className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-violet-500 focus:border-transparent resize-none"
              />
            </div>

            {/* Materials for Attendees */}
            <div className="mt-6">
              <label className="block text-sm font-medium text-slate-700 mb-2">
                <Upload className="w-4 h-4 inline mr-1" />
                Materials for Attendees
              </label>
              <div className="border-2 border-dashed border-slate-300 rounded-lg p-6 text-center hover:border-violet-400 transition-colors">
                <input
                  type="file"
                  multiple
                  onChange={handleFileUpload}
                  className="hidden"
                  id="file-upload"
                />
                <label
                  htmlFor="file-upload"
                  className="cursor-pointer"
                >
                  <Upload className="w-8 h-8 mx-auto mb-2 text-slate-400" />
                  <p className="text-sm text-slate-600 mb-1">
                    <span className="text-violet-600 font-medium">Click to upload</span> or drag and drop
                  </p>
                  <p className="text-xs text-slate-500">
                    PDF, DOC, DOCX, PPT, PPTX (max. 10MB)
                  </p>
                </label>
              </div>

              {/* Uploaded Files List */}
              {uploadedFiles.length > 0 && (
                <div className="mt-4 space-y-2">
                  {uploadedFiles.map((file) => (
                    <div
                      key={file.id}
                      className="flex items-center justify-between p-3 bg-slate-50 border border-slate-200 rounded-lg"
                    >
                      <div className="flex items-center gap-3">
                        <File className="w-5 h-5 text-violet-600" />
                        <div>
                          <div className="text-sm font-medium text-slate-900">{file.name}</div>
                          <div className="text-xs text-slate-500">{formatFileSize(file.size)}</div>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => removeFile(file.id)}
                        className="text-slate-500 hover:text-slate-700"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-4 justify-end">
            <button
              type="button"
              className="px-6 py-3 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-3 bg-gradient-to-r from-violet-500 to-purple-600 text-white rounded-lg hover:from-violet-600 hover:to-purple-700 transition-all shadow-sm"
            >
              Create Meeting
            </button>
          </div>
        </form>
      </div>

      {/* Meeting Details Modal */}
      <MeetingDetailsModal
        isOpen={showMeetingDetails}
        onClose={() => setShowMeetingDetails(false)}
        meetingData={{
          date: date,
          time: time ? (() => {
            const [hours, minutes] = time.split(':');
            const hour = parseInt(hours);
            const isPM = hour >= 12;
            const hour12 = hour > 12 ? hour - 12 : hour === 0 ? 12 : hour;
            return `${hour12}:${minutes} ${isPM ? 'PM' : 'AM'}`;
          })() : '',
          location: location || (meetingType === 'virtual' ? 'Virtual Meeting' : 'TBD'),
          host: {
            name: 'Current User',
            email: 'user@example.com'
          },
          attendees: participants.map(p => ({
            name: p.email.split('@')[0],
            email: p.email
          })),
          materials: uploadedFiles
        }}
      />
    </div>
  );
}