interface MeetingDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  meetingData: {
    date: string;
    time: string;
    location: string;
    host: {
      name: string;
      email: string;
    };
    attendees: Array<{
      name: string;
      email: string;
    }>;
    materials?: Array<{
      id: string;
      name: string;
      size: number;
    }>;
  };
}

export function MeetingDetailsModal({ isOpen, onClose, meetingData }: MeetingDetailsModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-8">
          {/* Title */}
          <h2 className="text-2xl mb-6">Meeting Details</h2>

          {/* Day, Time, Location */}
          <div className="mb-6">
            <div className="mb-2">
              <span className="font-semibold">Day:</span> {meetingData.date}
            </div>
            <div className="mb-2">
              <span className="font-semibold">Time:</span> {meetingData.time}
            </div>
            <div>
              <span className="font-semibold">Location:</span> {meetingData.location}
            </div>
          </div>

          {/* Divider */}
          <div className="border-t border-slate-200 my-6"></div>

          {/* Host */}
          <div className="mb-6">
            <h3 className="text-xl mb-2">Host</h3>
            <div className="text-slate-700">
              {meetingData.host.name} — {meetingData.host.email}
            </div>
          </div>

          {/* Divider */}
          <div className="border-t border-slate-200 my-6"></div>

          {/* Attendees */}
          <div className="mb-6">
            <h3 className="text-xl mb-4">Attendees</h3>
            <div className="space-y-4">
              {meetingData.attendees.map((attendee, index) => (
                <div key={index}>
                  <div className="font-medium text-slate-900">{attendee.name}</div>
                  <div className="text-slate-600">{attendee.email}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Divider */}
          <div className="border-t border-slate-200 my-6"></div>

          {/* Materials */}
          <div className="mb-8">
            <h3 className="text-xl mb-2">Materials for Attendees</h3>
            {meetingData.materials && meetingData.materials.length > 0 ? (
              <div className="space-y-2">
                {meetingData.materials.map((file) => (
                  <div key={file.id} className="text-slate-700">
                    {file.name}
                  </div>
                ))}
              </div>
            ) : (
              <div className="italic text-slate-600">No materials uploaded by the host.</div>
            )}
          </div>

          {/* Close Button */}
          <div className="flex justify-end">
            <button
              onClick={onClose}
              className="px-6 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors"
            >
              CLOSE
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}